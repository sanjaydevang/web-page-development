# Fundamentals of Web Development, 2nd Edition
### Chapter 7 [CSS 2], Project 3 [Travel]
Use the Bootstrap CSS framework (included with the start files, but you may want to
instead download the most recent version) as well as modify chapter07-project03.css
and chapter07-project03.html so it looks similar to that shown in Figure 7.57.

  
